﻿#include "pch.h"
#include <stdio.h>

void PrintData(int nData)
{
	printf("* PrintData() - %d\n", nData);
}

void PrintString(char* pszData)
{
	printf("PrintString() - %s\n", pszData);
}
