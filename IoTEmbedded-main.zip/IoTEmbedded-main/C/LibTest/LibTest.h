#pragma once
void PrintData(int nData);
void PrintString(char* pszData);
