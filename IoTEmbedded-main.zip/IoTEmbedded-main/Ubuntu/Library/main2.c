#include "Library.h"
#include <stdio.h>

struct Book* book = book_new();

